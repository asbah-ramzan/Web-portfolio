

/*----------------------------contact-------------------------*/
const form = document.querySelector('form');
const fullName = document.getElementById("name");
const email = document.getElementById("email");
const message = document.getElementById("message");

function sendEmail() {
    const bodyMessage = `fullName: ${fullName.value}<br> Email: ${email.value}<br> Message: ${message.value}`;
    Email.send({
        Host: "smtp.elasticemail.com",
        Username: "asbahramzan0@gmail.com",
        Password: "F25AB8912F7F78DB822D9354BAB8CFADFA86",
        To: 'asbahramzan0@gmail.com',
        From: "asbahramzan0@gmail.com",
        Subject: "This is the subject",
        Body: bodyMessage
    }).then(
        message => {
            if(message == "OK"){
                Swal.fire({
                    title: "Thank you for contact",
                    text: "we will respond  you soon",
                    icon: "success"
                  });

            }
        }
    );
}

form.addEventListener("submit", (e) => {
    e.preventDefault();
    sendEmail();
});
