/*================typing effect*/
var typed=new Typed(".typing",{
    strings:["Web Developer","Data Analyst","Web Designer",],
    typeSpeed:90,
    BackSpeed:20,
    loop:true
})
/*-------------typin end*/
